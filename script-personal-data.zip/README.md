# Script Personal Data

![JavaScript](https://img.shields.io/badge/JavaScript-Vanilla-f7df1e?style=flat-square&logo=javascript&logoColor=18181b)
![Manifest V3](https://img.shields.io/badge/Manifest-V3-7c3aed?style=flat-square)
![Browsers](https://img.shields.io/badge/Browsers-Firefox%20%7C%20Chrome%20%7C%20Edge%20%7C%20Brave-27272a?style=flat-square)

Extensão de navegador feita para eliminar o trabalho repetitivo de preencher nome, e-mail, telefone, LinkedIn, GitHub, portfólio, localização e pretensão salarial dezenas de vezes em plataformas de recrutamento diferentes (Gupy, Greenhouse, Lever, Workday, formulários próprios de empresas, entre outros) que não compartilham cadastro entre si.

Com um clique no botão flutuante no canto da tela, a extensão identifica os campos vazios da página atual, injeta os dados configurados e ainda oferece atalhos individuais de cópia para lidar com dropdowns customizados ou campos que bloqueiam preenchimento automático.

---

## Como funciona por baixo dos panos

Grande parte dos portais de vagas hoje roda em SPAs construídas com React, Next.js, Vue ou Angular. Nesses cenários, simplesmente atribuir `input.value = "valor"` não funciona como esperado: o framework mantém o estado interno sincronizado por meio de wrappers próprios e ignora mutações diretas na propriedade, fazendo o campo voltar a ficar vazio ou falhar na validação no momento do envio.

Para contornar isso, o motor de preenchimento usa o setter nativo do protótipo do DOM (`HTMLInputElement.prototype` / `HTMLTextAreaElement.prototype`):

```js
const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
setter.call(el, value);

el.dispatchEvent(new InputEvent('input', { bubbles: true, cancelable: true, data: value }));
el.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
el.dispatchEvent(new Event('blur', { bubbles: true, cancelable: true }));
```

Esse fluxo garante que o estado interno do componente controlado seja atualizado e que as validações vinculadas ao foco e à mudança de valor sejam disparadas corretamente.

Além disso, como o painel é injetado diretamente no DOM de páginas de terceiros (muitas vezes com resets agressivos de CSS, Tailwind ou Bootstrap), o contêiner da extensão utiliza `all: initial`, classes prefixadas (`afv-*`) e `z-index: 999999` para isolar o layout e a tipografia sem vazar estilos para o site hospedeiro.

---

## Funcionalidades

- **Preenchimento seletivo:** varre `<input>` visíveis e `<textarea>` da página (incluindo iframes de mesma origem) cruzando `placeholder`, `name`, `id`, `aria-label`, `autocomplete` e `<label>` associados em português e inglês.
- **Nunca sobrescreve o que você já digitou:** apenas campos vazios são preenchidos, recebendo uma borda verde por 1,5 segundo para confirmação visual.
- **Separação automática de nome e sobrenome:** se o formulário pedir *First Name* / *Last Name* (ou *Primeiro nome* / *Sobrenome*), a extensão divide o `Nome completo` automaticamente.
- **Botão de copiar por campo:** útil para selects customizados, máscaras rígidas ou formulários que exigem colar o valor manualmente.
- **Backup em JSON:** exporte e importe suas configurações em um arquivo `.json` para levar seus dados para outro navegador ou máquina.
- **Sem dependências externas:** JavaScript e CSS puros em Manifest V3, compatível com Firefox e navegadores baseados em Chromium.

---

## Instalação

Clone ou baixe este repositório para uma pasta local no seu computador antes de seguir os passos do seu navegador.

### Firefox

O Firefox permite carregar extensões sem assinatura de forma temporária (para testes) ou assiná-la como não listada (*self-distributed*) para mantê-la instalada de forma permanente.

**Teste rápido (temporário — removido ao fechar o navegador):**
1. Acesse `about:debugging#/runtime/this-firefox` na barra de endereços.
2. Clique em **Carregar extensão temporária...** (*Load Temporary Add-on...*).
3. Selecione o arquivo `manifest.json` na raiz do projeto.

**Uso permanente (assinatura gratuita via Mozilla):**
1. Compacte os arquivos da raiz (`manifest.json`, `content.js`, `styles.css` e a pasta `icons/`) em um arquivo `.zip` (sem pasta pai envolvendo o `manifest.json`).
2. Acesse o [Add-on Developer Hub](https://addons.mozilla.org/developers/) com sua conta Mozilla e clique em **Submit a New Add-on**.
3. Escolha a opção **On your own** (distribuição própria / não listada) e envie o `.zip`.
4. Assim que a validação automática concluir (geralmente em poucos minutos), baixe o arquivo `.xpi` assinado e arraste-o para dentro de uma aba do Firefox para instalar definitivamente.

### Chrome, Edge e Brave

1. Abra a página de extensões do navegador:
   - **Chrome:** `chrome://extensions`
   - **Edge:** `edge://extensions`
   - **Brave:** `brave://extensions`
2. Ative a opção **Modo do desenvolvedor** (*Developer mode*) no canto superior direito.
3. Clique em **Carregar sem compactação** (*Load unpacked*).
4. Selecione a pasta raiz deste projeto (onde está o `manifest.json`).

---

## Privacidade

Nenhum dado digitado na extensão é enviado para servidores externos, APIs de terceiros ou serviços de telemetria. Todo o perfil fica armazenado exclusivamente no `storage.local` do seu próprio navegador, e a extensão não faz nenhuma requisição de rede.
